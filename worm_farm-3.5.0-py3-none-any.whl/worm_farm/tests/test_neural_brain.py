import tempfile
import unittest
from pathlib import Path

import torch

from worm_farm import Claim, FarmConfig, WormFarm, TorchNeuralBrain, NeuralBrainConfig
from worm_farm.brain import CachedBrain
from worm_farm.neural_brain import ACTION_MODES


class NeuralBrainTests(unittest.TestCase):
    def _brain(self, seed=123):
        return TorchNeuralBrain(NeuralBrainConfig(hidden_dim=32, claim_buckets=24, seed=seed))

    def test_is_real_trainable_neural_network(self):
        b = self._brain()
        self.assertGreater(b.parameter_count, 1000)
        before = b.fingerprint()
        farm = WormFarm(FarmConfig(max_generations=1, founder_pairs=1))
        farm.seed(Claim(id="C", text="A synthetic claim should be attacked at its hidden boundary."))
        worm = next(iter(farm.state.worms.values()))
        proposal = b.propose(claim=farm.state.claims["C"], worm=worm, parent=None, context={"pressure": {}})
        self.assertIn("title", proposal)
        b.learn(worm_id=worm.id, reward=0.9)
        after = b.fingerprint()
        self.assertNotEqual(before, after)

    def test_checkpoint_restores_neural_weights(self):
        brain = CachedBrain(self._brain(55))
        farm = WormFarm(FarmConfig(max_generations=2, founder_pairs=1), brain=brain)
        farm.seed(Claim(id="C", text="The current framing may hide a boundary condition."))
        farm.run_generation()
        fp = brain.fingerprint()
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "brain.json"
            farm.save_checkpoint(path)
            restored = WormFarm.from_checkpoint(path, brain=CachedBrain(self._brain(55)))
            self.assertEqual(restored.brain.fingerprint(), fp)

    def test_factory_and_full_farm_integration(self):
        cfg = FarmConfig(max_generations=2, founder_pairs=2, brain_provider="torch-neural")
        farm = WormFarm(cfg)
        farm.seed(Claim(id="LIVE", text="The conventional framing is complete.", assumptions=["No alternative explanation matters."]))
        farm.run()
        self.assertEqual(farm.brain.name, "torch-neural-small")
        self.assertGreater(farm.report()["brain_calls"], 0)
        self.assertGreater(farm.report()["brain_cache_entries"], 0)
        delegate = farm.brain.delegate
        self.assertGreater(delegate.learn_steps, 0)
        self.assertGreater(delegate.parameter_count, 1000)


if __name__ == "__main__":
    unittest.main()
