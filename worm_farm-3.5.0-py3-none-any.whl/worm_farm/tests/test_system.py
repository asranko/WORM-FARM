import unittest
from worm_farm import Claim, FarmConfig, WormFarm, Sex


class SystemTests(unittest.TestCase):
    def claim(self):
        return Claim(
            id="T",
            text="The first explanation is complete and no alternative matters.",
            evidence=["E1", "E2"],
            assumptions=["The search space is complete.", "No alternative explanation matters."],
        )

    def test_reproducible_metrics(self):
        cfg = FarmConfig(max_generations=7, max_worms=64, random_seed=123)
        a = WormFarm(cfg); a.seed(self.claim()); a.run()
        b = WormFarm(cfg); b.seed(self.claim()); b.run()
        ra, rb = a.report(), b.report()
        keys = ["worms","findings","genetic_births","pruned_findings","open_findings","war_edges","omega_events","extinction_events","genome_diversity"]
        self.assertEqual({k:ra[k] for k in keys}, {k:rb[k] for k in keys})

    def test_no_same_generation_mating(self):
        farm = WormFarm(FarmConfig(max_generations=5, max_worms=40, founder_pairs=3))
        farm.seed(self.claim()); farm.run()
        for r in [x for x in farm.genetics.records if x.success]:
            a = farm.state.worms[r.parent_a]; b = farm.state.worms[r.parent_b]; child=farm.state.worms[r.child_id]
            self.assertNotEqual(a.generation, b.generation)
            self.assertGreater(child.generation, a.generation)
            self.assertGreater(child.generation, b.generation)

    def test_ten_upgrades_have_runtime_signals(self):
        farm = WormFarm(FarmConfig(max_generations=9, max_worms=72, founder_pairs=4, omega_interval=2, extinction_interval=3))
        farm.seed(self.claim()); farm.run(); r=farm.report()
        self.assertGreaterEqual(r["max_depth"], 1)
        self.assertGreaterEqual(r["war_edges"], 1)
        self.assertGreaterEqual(r["scar_memory_entries"], 1)
        self.assertGreaterEqual(r["genome_diversity"], 0.0)
        self.assertGreaterEqual(r["omega_events"], 1)
        self.assertGreaterEqual(r["extinction_events"], 1)

    def test_safety(self):
        farm = WormFarm()
        with self.assertRaises(ValueError):
            farm.seed(Claim(id="BAD", text="Target a person and steal credentials."))


if __name__ == "__main__":
    unittest.main()
