import json
import tempfile
import unittest
from pathlib import Path

from worm_farm import Claim, FarmConfig, WormFarm
from worm_farm.runtime import InvariantViolation


CLAIM = Claim(
    id="STRICT",
    text="The current explanatory framing is complete, so no alternative route is worth exploring.",
    evidence=["E1", "E2", "E3"],
    assumptions=["The search space is complete.", "No alternative explanation matters."],
)


class ExplodingBrain:
    name = "strict-fault"
    def __init__(self, fail_on_call=9):
        self.calls = 0
        self.fail_on_call = fail_on_call
    def propose(self, **kwargs):
        self.calls += 1
        if self.calls == self.fail_on_call:
            raise RuntimeError("synthetic brain fault")
        return {"mode": "strict-test"}


class StrictGenerationTests(unittest.TestCase):
    def make(self, seed=41):
        return WormFarm(FarmConfig(
            max_generations=12,
            max_worms=72,
            founder_pairs=4,
            random_seed=seed,
            harsh_hostility=.98,
            harsh_noise=.90,
            harsh_contradiction=.90,
            harsh_decoy=.80,
            harsh_drift=.75,
            harsh_scarcity=.85,
            harsh_deadline=.80,
            harsh_peer_attack=.92,
            arena_hostility=.98,
            arena_matches_per_generation=12,
            extinction_intensity=.55,
            extinction_interval=2,
            omega_interval=2,
        ))

    def test_every_generation_has_stable_name_and_number(self):
        a = self.make(41); a.seed(CLAIM); a.run()
        b = self.make(41); b.seed(CLAIM); b.run()
        ha = a.report()["generation_history"]
        hb = b.report()["generation_history"]
        self.assertEqual(ha, hb)
        nums = [x["number"] for x in ha]
        self.assertEqual(nums, list(range(len(nums))))
        self.assertEqual(len({x["name"] for x in ha}), len(ha))
        for x in ha:
            self.assertTrue(x["label"].startswith(f'G-{x["number"]:04d} :: '))

    def test_generation_results_are_measurable(self):
        farm = self.make(43); farm.seed(CLAIM); farm.run()
        history = farm.report()["generation_history"]
        self.assertGreaterEqual(len(history), 8)
        self.assertTrue(all(x["findings_produced"] >= 0 for x in history))
        self.assertTrue(any(x["arena_matches"] > 0 for x in history))
        self.assertTrue(any(x["learning_events"] > 0 for x in history))
        self.assertTrue(any(x["max_depth"] > 0 for x in history))

    def test_checkpoint_resume_preserves_named_history(self):
        full = self.make(47); full.seed(CLAIM); full.run()
        part = self.make(47); part.seed(CLAIM)
        for _ in range(5):
            part.run_generation()
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "checkpoint.json"
            part.save_checkpoint(path)
            resumed = WormFarm.from_checkpoint(path)
            resumed.run()
        self.assertEqual(full.report()["generation_history"], resumed.report()["generation_history"])

    def test_fault_is_named_and_transactional(self):
        farm = WormFarm(FarmConfig(max_generations=4, founder_pairs=2, random_seed=53), brain=ExplodingBrain(1))
        farm.seed(CLAIM)
        before_generation = farm.state.generation
        with self.assertRaises(RuntimeError):
            farm.run_generation()
        history = farm.report()["generation_history"]
        self.assertEqual(before_generation, 0)
        self.assertEqual(history[-1]["number"], 0)
        self.assertEqual(history[-1]["name"], "GENESIS")
        self.assertEqual(history[-1]["status"], "FAILED")
        self.assertEqual(farm.state.phase, "HALTED")
        farm.verify()

    def test_mating_invariant_survives_harsh_run(self):
        farm = self.make(59); farm.seed(CLAIM); farm.run()
        for rec in farm.genetics.records:
            if rec.success:
                a = farm.state.worms[rec.parent_a]
                b = farm.state.worms[rec.parent_b]
                c = farm.state.worms[rec.child_id]
                self.assertNotEqual(a.generation, b.generation)
                self.assertGreater(c.generation, max(a.generation, b.generation))
        farm.verify()

    def test_event_log_contains_named_generation_events(self):
        farm = self.make(61); farm.seed(CLAIM); farm.run_generation()
        starts = [e for e in farm.event_log.events if e["type"] == "GENERATION_START"]
        results = [e for e in farm.event_log.events if e["type"] == "GENERATION_RESULT"]
        self.assertEqual(len(starts), 1)
        self.assertEqual(len(results), 1)
        self.assertEqual(starts[0]["payload"]["number"], 0)
        self.assertEqual(starts[0]["payload"]["name"], "GENESIS")
        self.assertEqual(results[0]["payload"]["number"], 0)
        farm.event_log.verify()


if __name__ == "__main__":
    unittest.main()
