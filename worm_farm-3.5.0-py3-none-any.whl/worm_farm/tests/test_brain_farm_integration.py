import json
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from worm_farm import Claim, FarmConfig, WormFarm


PROPOSAL = {
    "title": "HTTP brain finding",
    "core_hypothesis": "The current framing omits a testable boundary condition.",
    "hidden_assumptions": ["The current framing captures all relevant variables."],
    "counterargument": "The apparent anomaly may come from incomplete evidence.",
    "falsifier": "A controlled synthetic counterexample leaves the outcome unchanged.",
    "novelty": 0.81,
    "information_gain": 0.79,
    "falsifiability": 0.91,
    "independence": 0.84,
}


class Handler(BaseHTTPRequestHandler):
    calls = 0

    def do_POST(self):
        Handler.calls += 1
        n = int(self.headers.get("Content-Length", "0"))
        self.rfile.read(n)
        payload = {"choices": [{"message": {"content": json.dumps(PROPOSAL)}}]}
        raw = json.dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def log_message(self, *_):
        return


class BrainFarmIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base_url = f"http://127.0.0.1:{cls.server.server_port}/v1"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.thread.join(timeout=2)

    def setUp(self):
        Handler.calls = 0

    def test_http_brain_is_in_the_generation_loop_and_checkpointed(self):
        cfg = FarmConfig(
            max_generations=1,
            max_worms=20,
            founder_pairs=2,
            brain_provider="openai-compatible",
            brain_base_url=self.base_url,
            brain_model="stub-model",
        )
        farm = WormFarm(cfg)
        farm.seed(Claim(id="LIVE", text="The current framing is complete.", assumptions=["The search space is complete."]))
        farm.run_generation()
        self.assertGreater(Handler.calls, 0)
        self.assertGreater(farm.report()["brain_calls"], 0)
        self.assertEqual(farm.report()["brain_provider"], "openai-compatible")
        self.assertEqual(farm.state.brain_cache and len(farm.state.brain_cache), farm.report()["brain_calls"])
        self.assertIn("HTTP brain finding", {f.title for f in farm.state.findings.values()})

        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "brain.json"
            farm.save_checkpoint(path)
            restored = WormFarm.from_checkpoint(path)
            self.assertEqual(len(restored.state.brain_cache), len(farm.state.brain_cache))
            self.assertEqual(restored.report()["brain_calls"], farm.report()["brain_calls"])


if __name__ == "__main__":
    unittest.main()
