import json
from pathlib import Path

import pytest

from worm_farm import Claim, FarmConfig, WormFarm
from worm_farm.genetics import GenomeEngine, GeneticsConfig, CognitiveGenome, Sex
from worm_farm.mode_router import EmpiricalRoutingSignal
from worm_farm.models import Worm, WormKind


def test_empirical_signal_uses_binary_outcome_only():
    s = EmpiricalRoutingSignal(smoothing_prior=0.5, prior_strength=4)
    assert s.confidence("X", "AR") == 0
    assert s.score("X", "AR") == pytest.approx(0.5)
    s.observe("X", "AR", True, True)
    s.observe("X", "AR", True, False)
    s.observe("X", "AR", False, True)
    assert s.confidence("X", "AR") == 3
    assert s.score("X", "AR") == pytest.approx(3.0 / 7.0)
    assert s.confidence("X", "DIFFUSION") == 0


def test_empirical_signal_ready_gate():
    s = EmpiricalRoutingSignal()
    for mode in ("AR", "DIFFUSION"):
        for _ in range(10):
            s.observe("X", mode, True, True)
    assert s.ready("X", 10)


def test_tournament_selector_is_reproducible_for_fixed_seed():
    cfg = GeneticsConfig(random_seed=123, selection_mode="tournament", tournament_size=4, tournament_temperature=1.0)
    ge1 = GenomeEngine(cfg)
    ge2 = GenomeEngine(cfg)
    assert ge1.config.selection_mode == "tournament"
    assert ge2.config.selection_mode == "tournament"


def test_tournament_selector_responds_to_routing_weighted_fitness_component():
    # Construct disjoint eligible candidates whose only changed component is routing_fitness.
    cfg = GeneticsConfig(random_seed=17, selection_mode="tournament", tournament_size=4, tournament_temperature=1.0)
    ge = GenomeEngine(cfg)
    males = []
    females = []
    genomes = {}
    for i in range(4):
        m = Worm(id=f"M{i}", kind=WormKind.SCOUT, target_claim_id="c", sex=Sex.MALE.value, generation=0,
                 reputation=.8, integrity=.8, energy=.9, resilience=.8, routing_fitness=.1 + .1*i)
        f = Worm(id=f"F{i}", kind=WormKind.SCOUT, target_claim_id="c", sex=Sex.FEMALE.value, generation=1,
                 reputation=.8, integrity=.8, energy=.9, resilience=.8, routing_fitness=.1 + .1*i)
        males.append(m); females.append(f)
        base={"novelty": 0.2 + 0.15 * i, "routing_bias": 0.5}
        mate = dict(base)
        mate["novelty"] = min(1.0, base["novelty"] + 0.15)
        genomes[m.id] = CognitiveGenome(dict(base), dict(base))
        genomes[f.id] = CognitiveGenome(dict(mate), dict(mate))
    selected = ge.choose_pairs(males+females, genomes, generation=2, max_pairs=2)
    assert 1 <= len(selected) <= 2
    assert all(a.sex != b.sex for a,b,_,_ in selected)
