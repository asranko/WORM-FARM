import unittest
from worm_farm import Claim,FarmConfig,WormFarm,Sex

class GeneticsTests(unittest.TestCase):
    def test_sexed_founders(self):
        farm=WormFarm(FarmConfig(founder_pairs=3,max_generations=1)); farm.seed(Claim(id="G",text="A complete model exists."))
        self.assertEqual(sum(w.sex==Sex.MALE.value for w in farm.state.worms.values()),3)
        self.assertEqual(sum(w.sex==Sex.FEMALE.value for w in farm.state.worms.values()),3)

    def test_same_generation_block(self):
        farm=WormFarm(FarmConfig(founder_pairs=1)); farm.seed(Claim(id="G2",text="A complete model exists."))
        ws=list(farm.state.worms.values()); m=next(w for w in ws if w.sex==Sex.MALE.value); f=next(w for w in ws if w.sex==Sex.FEMALE.value); f.generation=m.generation
        ok,reason,_=farm.genetics.eligible(m,f,0,farm.genomes)
        self.assertFalse(ok); self.assertEqual(reason,"same-generation mating prohibited")

    def test_child_generation(self):
        farm=WormFarm(FarmConfig(founder_pairs=4,max_generations=7,max_worms=70)); farm.seed(Claim(id="G3",text="Current framing is complete.")); farm.run()
        births=[r for r in farm.genetics.records if r.success]
        self.assertGreaterEqual(len(births),1)
        for r in births:
            a=farm.state.worms[r.parent_a]; b=farm.state.worms[r.parent_b]; c=farm.state.worms[r.child_id]
            self.assertNotEqual(a.generation,b.generation); self.assertGreater(c.generation,a.generation); self.assertGreater(c.generation,b.generation)

if __name__ == "__main__": unittest.main()
