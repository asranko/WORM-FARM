import copy
import unittest

from worm_farm import Claim, FarmConfig, WormFarm


class SelfDevelopmentTests(unittest.TestCase):
    def _claim(self):
        return Claim(
            id="sd-1",
            text="A simple model may appear complete while hiding an untested boundary condition.",
            assumptions=["the current framing captures the relevant variables"],
            evidence=["synthetic observation"],
        )

    def test_development_attempt_is_audited_and_bounded(self):
        cfg = FarmConfig(max_generations=4, self_development_interval=2, self_development_min_gain=0.001)
        farm = WormFarm(cfg)
        farm.seed(self._claim())
        farm.run()
        self.assertGreaterEqual(len(farm.state.development_events), 1)
        for event in farm.state.development_events:
            self.assertIn(event["parameter"], farm.self_development.PARAM_RANGES)
            self.assertTrue(0.0 <= event["candidate_value"] <= 2048.0 or event["parameter"] != "workspace_capacity_bits")

    def test_same_seed_repeats_development_log(self):
        cfg1 = FarmConfig(max_generations=4, self_development_interval=2, self_development_min_gain=0.0)
        cfg2 = copy.deepcopy(cfg1)
        a = WormFarm(cfg1); b = WormFarm(cfg2)
        a.seed(self._claim()); b.seed(self._claim())
        a.run(); b.run()
        self.assertEqual(a.snapshot()["state"]["development_events"], b.snapshot()["state"]["development_events"])
        self.assertEqual(a.config.prune_score, b.config.prune_score)
        self.assertEqual(a.config.min_spawn_score, b.config.min_spawn_score)

    def test_checkpoint_restores_development_controller(self):
        cfg = FarmConfig(max_generations=5, self_development_interval=2, self_development_min_gain=0.0)
        full = WormFarm(copy.deepcopy(cfg)); full.seed(self._claim()); full.run()
        part = WormFarm(copy.deepcopy(cfg)); part.seed(self._claim()); part.run_generation(); part.run_generation()
        ck = "/tmp/worm_farm_selfdev_checkpoint.json"
        part.save_checkpoint(ck)
        resumed = WormFarm.from_checkpoint(ck)
        resumed.run()
        self.assertEqual(full.snapshot()["state"]["development_events"], resumed.snapshot()["state"]["development_events"])
        self.assertEqual(full.self_development.runtime_state(), resumed.self_development.runtime_state())


if __name__ == "__main__":
    unittest.main()

try:
    import torch as _torch  # noqa: F401
    _TORCH_AVAILABLE = True
except Exception:
    _TORCH_AVAILABLE = False


@unittest.skipUnless(_TORCH_AVAILABLE, "PyTorch optional dependency is not installed")
class NeuralSelfDevelopmentTests(unittest.TestCase):
    def test_self_development_promotes_when_candidate_is_clearly_better(self):
        """Deterministic positive-control for the real promotion path."""
        cfg = FarmConfig(
            max_generations=2,
            self_development_enabled=True,
            self_development_interval=1,
            self_development_min_gain=0.05,
            self_development_max_trials=1,
            self_development_canary_generations=1,
            self_development_canary_seeds=3,
        )
        farm = WormFarm(cfg)
        farm.state.generation = 1
        calls = iter([(0.50, [0.50, 0.50, 0.50]), (0.95, [0.95, 0.95, 0.95])])
        farm.self_development._canary_mean = lambda *_args, **_kwargs: next(calls)
        before = farm.self_development.state_hash(farm)
        result = farm.self_development.attempt(farm, {"mean_quality":0.5, "diversity":0.2, "false_suspicion":0.0})
        self.assertIsNotNone(result)
        self.assertTrue(result.accepted)
        self.assertGreater(result.gain, 0.4)
        self.assertNotEqual(before, result.post_state_hash)

    def test_neural_brain_learns_and_self_development_can_promote(self):
        claim = Claim(
            id="sd-neural",
            text="A familiar model can hide a boundary condition under adversarial pressure.",
            assumptions=["the current framing is complete"],
            evidence=["synthetic"],
        )
        cfg = FarmConfig(
            max_generations=4,
            brain_provider="torch-neural",
            brain_hidden_dim=64,
            self_development_enabled=True,
            self_development_interval=2,
            self_development_min_gain=0.0005,
            self_development_max_trials=2,
            self_development_canary_generations=2,
            self_development_canary_seeds=3,
            max_findings_per_generation=8,
            max_audits_per_generation=4,
            arena_matches_per_generation=4,
        )
        farm = WormFarm(cfg)
        farm.seed(claim)
        start_fp = farm.brain.fingerprint()
        farm.run()
        self.assertNotEqual(start_fp, farm.brain.fingerprint())
        self.assertGreater(getattr(farm.brain.delegate, "learn_steps", 0), 0)
        self.assertGreaterEqual(len(farm.state.development_events), 1)
        self.assertGreaterEqual(len(farm.state.development_promotions), 1)
        self.assertEqual(
            farm.config.brain_learning_rate,
            farm.brain.delegate.config.learning_rate,
        )

