import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from worm_farm import Claim, FarmConfig, WormFarm
from worm_farm.brain import CachedBrain, HTTPBrain, BrainProtocolError, validate_proposal


VALID = {
    "title": "Boundary breach",
    "core_hypothesis": "The current framing omits a boundary condition.",
    "hidden_assumptions": ["The current framing captures all relevant variables."],
    "counterargument": "The anomaly may come from missing evidence.",
    "falsifier": "A synthetic counterexample leaves the outcome unchanged.",
    "novelty": 0.73,
    "information_gain": 0.74,
    "falsifiability": 0.88,
    "independence": 0.81,
}


class StubHandler(BaseHTTPRequestHandler):
    calls = 0
    last_body = None
    mode = "openai"

    def do_POST(self):
        StubHandler.calls += 1
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length)
        StubHandler.last_body = json.loads(body.decode("utf-8"))
        if StubHandler.mode == "ollama":
            payload = {"message": {"content": json.dumps(VALID)}}
        else:
            payload = {"choices": [{"message": {"content": json.dumps(VALID)}}]}
        raw = json.dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def log_message(self, *_):
        return


class BrainIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), StubHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}/v1"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.thread.join(timeout=2)

    def setUp(self):
        StubHandler.calls = 0
        StubHandler.last_body = None

    def test_openai_compatible_http_brain_is_real_and_structured(self):
        brain = HTTPBrain(base_url=self.base, model="stub-model", provider="openai_compatible")
        farm = WormFarm(FarmConfig(max_generations=1))
        farm.seed(Claim(id="TMP", text="Synthetic claim."))
        worm = next(iter(farm.state.worms.values()))
        proposal = brain.propose(
            claim=Claim(id="C", text="The first framing is complete."),
            worm=worm,
            parent=None,
            context={"pressure": {"hostility": 0.7}},
        )
        self.assertEqual(proposal["title"], "Boundary breach")
        self.assertEqual(StubHandler.calls, 1)
        self.assertIn("messages", StubHandler.last_body)

    def test_ollama_response_shape(self):
        StubHandler.mode = "ollama"
        brain = HTTPBrain(base_url=self.base, model="stub-model", provider="ollama")
        farm = WormFarm(FarmConfig(max_generations=1))
        farm.seed(Claim(id="C2", text="The current framing is complete."))
        worm = next(iter(farm.state.worms.values()))
        proposal = brain.propose(claim=farm.state.claims["C2"], worm=worm, parent=None, context={})
        self.assertEqual(validate_proposal(proposal).title, "Boundary breach")
        self.assertEqual(StubHandler.calls, 1)
        StubHandler.mode = "openai"

    def test_cache_avoids_second_http_call_and_farm_consumes_brain(self):
        farm = WormFarm(FarmConfig(max_generations=1, founder_pairs=2))
        farm.seed(Claim(id="C3", text="The current framing is complete."))
        raw = HTTPBrain(base_url=self.base, model="stub-model", provider="openai_compatible")
        farm.brain = CachedBrain(raw, farm.state.brain_cache)
        farm.brain.cache = farm.state.brain_cache
        worm = next(iter(farm.state.worms.values()))
        claim = farm.state.claims["C3"]
        context = {"pressure": {}, "generation_name": "GENESIS"}
        a = farm.brain.propose(claim=claim, worm=worm, parent=None, context=context)
        b = farm.brain.propose(claim=claim, worm=worm, parent=None, context=context)
        self.assertEqual(a, b)
        self.assertEqual(StubHandler.calls, 1)

    def test_invalid_brain_payload_is_rejected(self):
        with self.assertRaises(BrainProtocolError):
            validate_proposal({"title": "x"})


if __name__ == "__main__":
    unittest.main()
