import json
import tempfile
import unittest
from pathlib import Path

from worm_farm import Claim, FarmConfig, WormFarm
from worm_farm.invariants import InvariantViolation


class RuntimeHardeningTests(unittest.TestCase):
    def claim(self):
        return Claim(
            id="RUNTIME",
            text="The first explanatory framing is complete.",
            evidence=["E1", "E2", "E3"],
            assumptions=["The search space is complete.", "No alternative explanation matters."],
        )

    def make(self, seed=77):
        return WormFarm(FarmConfig(
            max_generations=8, max_worms=64, founder_pairs=4,
            omega_interval=2, extinction_interval=3, random_seed=seed,
        ))

    def test_checkpoint_resume_matches_full_run(self):
        full = self.make(); full.seed(self.claim()); full.run()
        partial = self.make(); partial.seed(self.claim())
        for _ in range(4): partial.run_generation()
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "checkpoint.json"
            partial.save_checkpoint(path)
            resumed = WormFarm.from_checkpoint(path)
            resumed.run()
        self.assertEqual(full.report(), resumed.report())
        full.verify(); resumed.verify()

    def test_event_chain_detects_tampering(self):
        farm = self.make(); farm.seed(self.claim()); farm.run_generation()
        payload = farm.snapshot()
        payload["runtime"]["event_log"][0]["payload"]["claim_id"] = "TAMPERED"
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "bad.json"
            path.write_text(json.dumps({"version": 1, "payload": payload}), encoding="utf-8")
            with self.assertRaises(InvariantViolation):
                WormFarm.from_checkpoint(path)

    def test_ids_are_stable(self):
        a = self.make(31); a.seed(self.claim()); a.run_generation()
        b = self.make(31); b.seed(self.claim()); b.run_generation()
        self.assertEqual(sorted(a.state.worms), sorted(b.state.worms))
        self.assertEqual(sorted(a.state.findings), sorted(b.state.findings))


if __name__ == "__main__":
    unittest.main()

class ExplodingBrain:
    name = "exploding"
    def propose(self, **kwargs):
        raise RuntimeError("synthetic brain outage")


class ProductionBehaviorTests(unittest.TestCase):
    def test_generation_transaction_rolls_back_on_brain_failure(self):
        farm = WormFarm(FarmConfig(max_generations=3, max_worms=20, founder_pairs=2), brain=ExplodingBrain())
        farm.seed(Claim(id="TX", text="The first framing is complete."))
        before = farm.snapshot()
        with self.assertRaises(RuntimeError):
            farm.run_generation()
        # All domain mutations from the failed generation are rolled back.
        after = farm.snapshot()
        self.assertEqual(before["state"]["claims"], after["state"]["claims"])
        self.assertEqual(before["state"]["worms"], after["state"]["worms"])
        self.assertEqual(before["state"]["findings"], after["state"]["findings"])
        self.assertEqual(before["genomes"], after["genomes"])
        self.assertEqual(before["runtime"]["finding_seq"], after["runtime"]["finding_seq"])
        self.assertEqual(after["state"]["phase"], "HALTED")
        farm.verify()
