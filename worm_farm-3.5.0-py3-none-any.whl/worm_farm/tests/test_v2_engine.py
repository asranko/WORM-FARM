import tempfile
import unittest
from pathlib import Path

from worm_farm import Claim, FarmConfig, EvolvingWormFarm, WORMBench

CLAIM = Claim(
    id="V2",
    text="The observed explanation is complete and no alternative variable matters.",
    evidence=["E1", "E2"],
    assumptions=["The search boundary is already known.", "No alternative explanation matters."],
)


class V2Tests(unittest.TestCase):
    def make(self, seed=77, generations=6):
        return EvolvingWormFarm(FarmConfig(max_generations=generations, max_worms=56, founder_pairs=3, random_seed=seed))

    def test_strategy_is_active_and_specialist_conditioned(self):
        farm = self.make(); farm.seed(CLAIM); farm.run()
        self.assertEqual(len(farm.strategy_genomes), len(farm.state.worms))
        self.assertGreaterEqual(farm.report()["strategy_history"], len(farm.state.worms))
        self.assertGreaterEqual(farm.report()["strategy_diversity"], 0.0)

    def test_checkpoint_resume_preserves_v2_digest(self):
        full = self.make(88); full.seed(CLAIM); full.run()
        part = self.make(88); part.seed(CLAIM); part.run_generation(); part.run_generation()
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "v2.json"
            part.save_checkpoint(path)
            resumed = EvolvingWormFarm.from_checkpoint(path)
            resumed.run()
        self.assertEqual(full.report()["generation_history"], resumed.report()["generation_history"])
        self.assertEqual(full.report()["strategy_diversity"], resumed.report()["strategy_diversity"])
        self.assertEqual(
            {wid: g.digest() for wid, g in full.strategy_genomes.items()},
            {wid: g.digest() for wid, g in resumed.strategy_genomes.items()},
        )

    def test_strategy_influences_policy(self):
        farm = self.make(91, 2); farm.seed(CLAIM)
        worms = list(farm.state.worms.values())
        a, b = worms[:2]
        pa = farm._sync_strategy_to_worm(a)
        pb = farm._sync_strategy_to_worm(b)
        self.assertNotEqual(pa, pb)

    def test_bench_runs(self):
        bench = WORMBench()
        tasks = bench.make_tasks(1)
        r = bench.run_trial(tasks[0], "single", 1, generations=2)
        self.assertEqual(r.generations, 2)
        self.assertTrue(r.deterministic_digest)

if __name__ == "__main__":
    unittest.main()
