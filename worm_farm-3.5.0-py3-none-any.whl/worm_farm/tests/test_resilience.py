import unittest
from worm_farm import Claim, FarmConfig, WormFarm

class ResilienceTests(unittest.TestCase):
    def test_rehabilitation_can_reopen_population(self):
        f=WormFarm(FarmConfig(max_generations=6,max_worms=30,founder_pairs=2))
        f.seed(Claim(id='RR', text='The first framing is complete.'))
        # Directly create a recoverable cooldown state for a deterministic unit test.
        for w in f.state.worms.values():
            w.status='COOLDOWN'; w.cooldown_until=0; w.integrity=.7; w.reputation=.7; w.resilience=.7; w.adaptation=.7
        f.state.generation=1
        recovered=f._rehabilitation_reserve()
        self.assertGreaterEqual(recovered, 1)
        self.assertTrue(f.active_worms if hasattr(f,'active_worms') else True)

if __name__=='__main__': unittest.main()
