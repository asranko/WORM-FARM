import unittest
from worm_farm import Claim, FarmConfig, WormFarm

class FarmSmokeTests(unittest.TestCase):
    def test_recursive_activity(self):
        farm=WormFarm(FarmConfig(max_generations=4,max_worms=40)); farm.seed(Claim(id="C",text="The current framing is complete.",assumptions=["The search space is complete."])); farm.run()
        self.assertGreater(len(farm.state.worms),1); self.assertGreater(len(farm.state.findings),0)

    def test_rewards_and_penalties(self):
        farm=WormFarm(FarmConfig(max_generations=5,max_worms=50,prune_score=.98)); farm.seed(Claim(id="C2",text="Because A therefore B.",assumptions=["The causal bridge is valid."])); farm.run()
        r=farm.report(); self.assertIn("rewards_total",r); self.assertIn("penalties_total",r)

if __name__ == "__main__": unittest.main()
