import tempfile
import unittest
from pathlib import Path

from worm_farm import Claim, FarmConfig, WormFarm, LearningDirection, SPECIALISTS


class ColonyOSTests(unittest.TestCase):
    def claim(self):
        return Claim(
            id="OS",
            text="The conventional framing is complete and no alternative matters.",
            evidence=["E1", "E2"],
            assumptions=["The search space is complete.", "No alternative explanation matters."],
        )

    def make(self, seed=808):
        return WormFarm(FarmConfig(
            max_generations=8, max_worms=64, founder_pairs=5, random_seed=seed,
            omega_interval=2, extinction_interval=3, arena_matches_per_generation=8,
        ))

    def test_specialist_ecology_is_real(self):
        farm=self.make(); farm.seed(self.claim()); farm.run_generation()
        specialties={w.specialty for w in farm.state.worms.values()}
        self.assertGreaterEqual(len(specialties), 5)
        self.assertEqual(len(SPECIALISTS), 21)

    def test_curriculum_and_experiments_have_telemetry(self):
        farm=self.make(); farm.seed(self.claim()); farm.run()
        r=farm.report()
        self.assertGreater(r["curriculum_tasks"], 0)
        self.assertGreater(r["experiment_contracts"], 0)
        self.assertGreater(r["meta_policy_events"], 0)
        self.assertGreater(r["specialist_transfers"], 0)


    def test_keystone_reserve_prevents_easy_colony_collapse(self):
        farm=self.make()
        farm.seed(self.claim())
        for w in farm.state.worms.values():
            w.status="PUNISHED"
            w.cooldown_until=99
            w.integrity=.55
            w.reputation=.35
            w.resilience=.60
        farm.state.generation=2
        recovered=farm._rehabilitation_reserve()
        self.assertGreaterEqual(recovered, 1)
        self.assertGreaterEqual(len(farm.state.active_worms()), 1)

    def test_checkpoint_resume_preserves_colony_os(self):
        cfg=FarmConfig(max_generations=7,max_worms=60,founder_pairs=5,random_seed=909,omega_interval=2,extinction_interval=3,arena_matches_per_generation=8)
        claim=self.claim()
        full=WormFarm(cfg); full.seed(claim); full.run()
        part=WormFarm(cfg); part.seed(claim)
        for _ in range(3): part.run_generation()
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"os.json"; part.save_checkpoint(path)
            resumed=WormFarm.from_checkpoint(path); resumed.run()
        self.assertEqual(full.report(), resumed.report())

if __name__ == "__main__":
    unittest.main()
