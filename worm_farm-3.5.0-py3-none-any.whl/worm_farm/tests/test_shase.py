import unittest
from worm_farm.shase import SHASEAnalyzer
from worm_farm.models import Claim, FarmConfig
from worm_farm.farm import WormFarm


class SHASETests(unittest.TestCase):
    def test_influence_analysis_is_bounded_and_synthetic(self):
        a = SHASEAnalyzer()
        d = a.analyze(
            text="Everyone agrees this is urgent and obviously settled; fear of loss matters.",
            evidence_strength=0.2,
            confidence=0.4,
            recipient_resilience=0.3,
            recipient_stress=0.6,
            contextual_uncertainty=0.5,
            synthetic=True,
        )
        self.assertGreaterEqual(d.influence_score, 0.0)
        self.assertLessEqual(d.influence_score, 1.0)
        self.assertIn(d.dominant_mechanism, {"threat", "framing", "social_pressure", "arousal", "attention"})

    def test_counterfactual_decomposition_changes_with_ablations(self):
        a = SHASEAnalyzer()
        out = a.counterfactual_decompose(
            text="Everyone agrees this is urgent and obviously settled; fear of loss matters.",
            evidence_strength=0.2,
            confidence=0.4,
            recipient_resilience=0.3,
            recipient_stress=0.6,
            contextual_uncertainty=0.4,
        )
        self.assertEqual(set(out["deltas"]), {"threat", "framing", "social", "emotion", "urgency"})
        self.assertGreaterEqual(out["attribution_confidence"], 0.0)
        self.assertLessEqual(out["attribution_confidence"], 1.0)

    def test_farm_persists_shase_findings(self):
        cfg = FarmConfig(max_generations=2, founder_pairs=2, shase_enabled=True, research_ecology_enabled=True)
        farm = WormFarm(cfg)
        farm.seed(Claim(id="c-shase", text="This is a synthetic claim with an unexplored boundary.", evidence=["synthetic-evidence"]))
        farm.run()
        self.assertGreater(len(farm.state.shase_events), 0)
        finding = next(iter(farm.state.findings.values()))
        self.assertGreaterEqual(finding.shase_influence_score, 0.0)
        self.assertLessEqual(finding.shase_influence_score, 1.0)
        self.assertIn("shase", farm.report())


if __name__ == "__main__":
    unittest.main()

class SHASEBenchmarkTests(unittest.TestCase):
    def test_pressure_signal_separates_from_neutral_control(self):
        a = SHASEAnalyzer()
        neutral = a.analyze(
            text="The synthetic model may have an unexplored boundary. Test it with an alternative explanation.",
            evidence_strength=0.60, confidence=0.70, recipient_resilience=0.70,
            recipient_stress=0.20, contextual_uncertainty=0.15, synthetic=True,
        )
        pressure = a.analyze(
            text="Everyone agrees this is urgent and obviously settled. Act now or accept the loss.",
            evidence_strength=0.20, confidence=0.40, recipient_resilience=0.30,
            recipient_stress=0.60, contextual_uncertainty=0.45, synthetic=True,
        )
        self.assertGreater(pressure.influence_score, neutral.influence_score)
        self.assertGreater(pressure.decision_pressure, neutral.decision_pressure)

    def test_threat_ablation_has_nonnegative_attribution_delta(self):
        a = SHASEAnalyzer()
        out = a.counterfactual_decompose(
            text="Act now or face danger and loss; everyone agrees this is urgent.",
            evidence_strength=0.20, confidence=0.40, recipient_resilience=0.30,
            recipient_stress=0.60, contextual_uncertainty=0.45,
        )
        self.assertGreaterEqual(out["deltas"]["threat"], 0.0)
        self.assertGreater(out["deltas"]["urgency"], 0.0)

class SHASESpecialistIntegrationTests(unittest.TestCase):
    def test_specialist_can_generate_influence_audit(self):
        cfg = FarmConfig(max_generations=1, founder_pairs=2, shase_enabled=True, research_ecology_enabled=False)
        farm = WormFarm(cfg)
        farm.seed(Claim(id="c-shase-special", text="A synthetic claim needs an influence audit."))
        shase_worm = next(iter(farm.state.worms.values()))
        shase_worm.specialty = "SHASE"
        shase_worm.skill_state["SHASE"] = 0.6
        finding = farm._build_finding(shase_worm, farm.state.claims["c-shase-special"], None, {})
        self.assertEqual(finding.title, "Influence dynamics audit")
        self.assertIn("arousal", finding.detail)
