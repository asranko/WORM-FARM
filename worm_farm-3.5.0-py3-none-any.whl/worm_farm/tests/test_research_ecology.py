from worm_farm.models import Finding, Worm, WormKind, FarmConfig
from worm_farm.research_ecology import InformationLimitedWorkspace, ResearchEcology
from worm_farm.farm import WormFarm


def _worm(i, specialty):
    return Worm(id=f"W{i}", kind=WormKind.SCOUT, target_claim_id="C", specialty=specialty, generation=0)


def _finding(fid, wid, score=0.8):
    return Finding(
        id=fid, worm_id=wid, kind=WormKind.SCOUT, depth=1,
        title=f"F{fid}", detail="detail",
        novelty=0.7, information_gain=0.8, validity=score,
        falsifiability=0.8, independence=0.8, counterfactual_score=0.7,
        robustness=0.8,
    )


def test_workspace_hard_capacity():
    bus = InformationLimitedWorkspace(capacity_bits=128, noise=0.0, message_base_bits=64)
    worms = [_worm(1, "A"), _worm(2, "B")]
    ec = ResearchEcology(128, 0.0, 64)
    result = ec.process_generation(0, worms, [_finding("F1", "W1"), _finding("F2", "W2")])
    assert result["used_bits"] <= 128
    assert result["accepted"] + result["rejected"] == 2
    assert result["equivocation"] >= 0.0


def test_research_deterministic():
    worms = [_worm(1, "A"), _worm(2, "B"), _worm(3, "C")]
    findings = [_finding("F1", "W1"), _finding("F2", "W2"), _finding("F3", "W3")]
    a = ResearchEcology(256, 0.08, 64).process_generation(0, worms, findings)
    b = ResearchEcology(256, 0.08, 64).process_generation(0, worms, findings)
    assert a == b


def test_research_checkpoint_resume():
    cfg = FarmConfig(max_generations=3, max_worms=32, workspace_capacity_bits=256, research_message_base_bits=64)
    from worm_farm.models import Claim
    full = WormFarm(cfg)
    full.seed(Claim(id="C", text="The search space is complete."))
    for _ in range(3):
        full.run_generation()
    full_report = full.report()

    part = WormFarm(cfg)
    part.seed(Claim(id="C", text="The search space is complete."))
    part.run_generation()
    ck = "/tmp/worm_farm_research_checkpoint.json"
    part.save_checkpoint(ck)
    resumed = WormFarm.from_checkpoint(ck)
    resumed.run()
    assert resumed.report()["generation_history"] == full_report["generation_history"]
    assert resumed.report()["research_ecology"] == full_report["research_ecology"]


def test_research_integrates_into_generation():
    cfg = FarmConfig(max_generations=1, max_worms=32, workspace_capacity_bits=256, research_message_base_bits=64)
    from worm_farm.models import Claim
    farm = WormFarm(cfg)
    farm.seed(Claim(id="C", text="The search space is complete."))
    farm.run()
    assert len(farm.state.research_events) == 1
    assert "RESEARCH_WORKSPACE" in [e["type"] for e in farm.event_log.events]
    statuses = [f.workspace_status for f in farm.state.findings.values()]
    assert statuses
    assert any(s in {"SHARED", "PRIVATE"} for s in statuses)


def test_workspace_reaches_next_brain_context():
    from worm_farm.models import Claim
    from worm_farm.brain import StaticBrain, BrainPromptBuilder
    cfg = FarmConfig(max_generations=2, max_worms=24, founder_pairs=2, workspace_capacity_bits=256)
    farm = WormFarm(cfg, brain=StaticBrain())
    farm.seed(Claim(id="C", text="The known framing is complete."))
    farm.run_generation()
    assert farm.state.shared_workspace
    worm = farm.state.active_worms()[0]
    claim = farm.state.claims["C"]
    messages = BrainPromptBuilder().build(claim=claim, worm=worm, parent=None, context={"shared_workspace": farm.state.shared_workspace})
    assert "shared_workspace" in messages[1]["content"]
