import tempfile
import unittest
from pathlib import Path
from worm_farm import Claim, FarmConfig, WormFarm


class ArenaLearningTests(unittest.TestCase):
    def claim(self):
        return Claim(
            id="ARENA",
            text="The conventional framing is complete.",
            evidence=["E1", "E2"],
            assumptions=["The search space is complete.", "No alternative matters."],
        )

    def test_arena_produces_fierce_closed_competition_and_learning(self):
        farm = WormFarm(FarmConfig(max_generations=5, max_worms=48, arena_matches_per_generation=8, founder_pairs=4))
        farm.seed(self.claim())
        farm.run()
        report = farm.report()
        self.assertGreaterEqual(report["arena_matches"], 1)
        self.assertGreaterEqual(report["arena_wins"] + report["arena_losses"] + report["arena_draws"], 1)
        self.assertGreaterEqual(report["learning_events"], 1)
        self.assertIn("peer", report["learning_channels"])
        self.assertGreaterEqual(len(report["arena_modes"]), 2)
        self.assertGreaterEqual(len(report["arena_leaderboard"]), 2)

    def test_config_isolation_between_farms(self):
        cfg = FarmConfig(max_generations=2, max_worms=32, founder_pairs=3)
        a = WormFarm(cfg); b = WormFarm(cfg)
        a.config.prune_score = 0.123
        self.assertNotEqual(a.config.prune_score, b.config.prune_score)
        self.assertEqual(cfg.prune_score, FarmConfig().prune_score)

    def test_arena_checkpoint_resume(self):
        cfg = FarmConfig(max_generations=7, max_worms=56, arena_matches_per_generation=6, founder_pairs=4, random_seed=91)
        claim = self.claim()
        full = WormFarm(cfg); full.seed(claim); full.run()
        partial = WormFarm(cfg); partial.seed(claim)
        for _ in range(3): partial.run_generation()
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "arena.json"
            partial.save_checkpoint(path)
            resumed = WormFarm.from_checkpoint(path)
            resumed.run()
        self.assertEqual(full.report(), resumed.report())

if __name__ == "__main__":
    unittest.main()
