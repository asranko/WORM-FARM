import unittest
from worm_farm import Claim,FarmConfig,WormFarm

class HarshTests(unittest.TestCase):
    def test_pressure_and_adaptation(self):
        farm=WormFarm(FarmConfig(max_generations=5,max_worms=50,harsh_learning=True)); farm.seed(Claim(id="H",text="The first explanation is complete.")); farm.run()
        self.assertTrue(any(w.hostility_exposure>0 for w in farm.state.worms.values()))
        self.assertTrue(any(w.successful_adaptations+w.failures>0 for w in farm.state.worms.values()))

    def test_toggle(self):
        farm=WormFarm(FarmConfig(max_generations=2,max_worms=20,harsh_learning=False)); farm.seed(Claim(id="H2",text="The first explanation is complete.")); farm.run()
        self.assertFalse(farm.config.harsh_learning)

if __name__ == "__main__": unittest.main()
