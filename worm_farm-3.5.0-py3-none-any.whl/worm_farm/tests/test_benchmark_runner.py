import tempfile
import unittest
from pathlib import Path

from worm_farm.benchmark_runner import run_benchmark, summarize, save
from worm_farm.experiment_lab import WORMBench


class BenchmarkRunnerTests(unittest.TestCase):
    def test_small_benchmark(self):
        task = WORMBench().make_tasks(1)[0]
        results = run_benchmark(tasks=[task], seeds=[1, 2], generations=3, architectures=["single", "worm_v2", "worm_v2_no_arena"])
        self.assertEqual(len(results), 6)
        self.assertTrue(all(r.generations == 3 for r in results))
        self.assertEqual(len(summarize(results)), 3)

    def test_save(self):
        task = WORMBench().make_tasks(1)[0]
        results = run_benchmark(tasks=[task], seeds=[3], generations=2, architectures=["worm_v2"])
        with tempfile.TemporaryDirectory() as td:
            save(results, summarize(results), Path(td))
            for name in ["trials.json", "trials.csv", "summaries.json", "RESULTS.md"]:
                self.assertTrue((Path(td) / name).exists())

if __name__ == "__main__":
    unittest.main()
